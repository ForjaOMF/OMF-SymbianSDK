/*
 * ============================================================================
 *  Name     : CClientAppUi of ClientAppUI.cpp
 *  Part of  : SMS20 Example for symbian sdk
 *  Created  : 22/05/2008
 *  Version  : 1.0
 *  Copyright:
 * ============================================================================
 */

#include <avkon.hrh>
#include <aknnotewrappers.h>
#include <eikmenup.h>

#include <SMS20Example.rsg>
#include "Client.pan"
#include "ClientAppUi.h"
#include "ClientAppView.h"
#include "Client.hrh"

// Schemes for given uris
_LIT(KHttpPrefix, "http://");
_LIT8(KHttpPrefix8, "http://");

// HTTPS schemes
_LIT(KHttpsPrefix, "https://");
_LIT8(KHttpsPrefix8, "https://");

_LIT8(KMimeType, "text/plain");

const TInt KDefaultBufferSize = 256;

// ----------------------------------------------------------------------------
// CClientAppUi::ConstructL()
//
// Second phase construction.
// ----------------------------------------------------------------------------
void CClientAppUi::ConstructL()
	{
    BaseConstructL(EAknEnableSkin);

    iAppView = CClientAppView::NewL(ClientRect());
    AddToStackL(iAppView);

	iClient = CSMS20::NewL();
	
		// SMS20 constants
		_LIT8(klogin8, "669554455");
		_LIT8(kpsw8, "1234");
		_LIT8(kAlias, "myself");
		
		_LIT8(kconntact, "669553355");
		_LIT8(kmsg, "hello world");
		
		HBufC8* 		hresponse;
		HBufC8*			output;		
		RPointerArray<CContactoSMS20> CList;
		RPointerArray<CContactoSMS20> PList;
		
		iAppView->ResetL();
		
		// loggin in SMS20 platform
		hresponse= iClient->Login(klogin8, kpsw8);
		
		TRAPD(err_1, iAppView->AddToOutputWindowL(hresponse->Des()));
			if(err_1)
				Panic(EClientView);
		
		iAppView->ResetL();
		
		if (hresponse->Length() > 1)
			{
			// activate session		
			CList = iClient->Connect(kAlias);
			
			// get server response
			hresponse = iClient->Polling();
			
			// get presence list
			if (hresponse->Des().Left(1) == _L8("<"))
					{
					CContactoSMS20* contacto;
					PList = iClient->GetPresenceList(hresponse->Des());
					
					output = HBufC8::NewL(5500);
					output->Des().Copy(_L8(""));
					
					TInt pos = 0;
					while (pos < CList.Count())
						{
							contacto = (CList)[pos++];
							output->Des().Append(contacto->GetAlias());
							output->Des().Append(_L8(" | "));
							output->Des().Append(contacto->GetUserID());
							output->Des().Append(_L8(" | "));
							if (contacto->GetPresence() != EFalse)
								{
								output->Des().Append(_L8(" O"));
								}
							else
								{
								output->Des().Append(_L8(" _"));
								}
							output->Des().Append(_L8(", "));
						}
					}		
					
			TRAPD(err_2, iAppView->AddToOutputWindowL(output->Des()));
				if(err_2)
					Panic(EClientView);
			
			iAppView->ResetL();
			
			// add contact
			hresponse = iClient->AddContact(kconntact);
			
			TRAPD(err_3, iAppView->AddToOutputWindowL(hresponse->Des()));
				if(err_3)
					Panic(EClientView);
			
			iAppView->ResetL();
			
			// autorice contact	
			iClient->AuthorizeContact(kconntact);
			
			TRAPD(err_4, iAppView->AddToOutputWindowL(_L8("Autoriced")));
				if(err_4)
					Panic(EClientView);
			
			iAppView->ResetL();
			
			// send message
			iClient->SendMessage(kconntact, kmsg);
			
			TRAPD(err_5, iAppView->AddToOutputWindowL(_L8("Sended")));
				if(err_5)
					Panic(EClientView);
			
			iAppView->ResetL();
			
			// delete contact
			iClient->DeleteContact(kconntact);
			
			TRAPD(err_6, iAppView->AddToOutputWindowL(_L8("deleted")));
				if(err_6)
					Panic(EClientView);
			
			iAppView->ResetL();
			
			// logout		
			iClient->Logout();
			
			TRAPD(err_7, iAppView->AddToOutputWindowL(_L8("logout")));
				if(err_7)
					Panic(EClientView);
			}
	}

// ----------------------------------------------------------------------------
// CClientAppUi::CClientAppUi()
//
// First phase construction.
// ----------------------------------------------------------------------------
CClientAppUi::CClientAppUi()
	{
	}

// ----------------------------------------------------------------------------
// CClientAppUi::~CClientAppUi()
//
// Destructor.
// ----------------------------------------------------------------------------
CClientAppUi::~CClientAppUi()
	{
	delete iClient;
	if (iAppView)
		{
		iEikonEnv->RemoveFromStack(iAppView);
		delete iAppView;
		}
	}
	
	
// ----------------------------------------------------------------------------
// CClientAppUi::HandleCommandL()
//
// Handles user commands.
// ----------------------------------------------------------------------------
void CClientAppUi::HandleCommandL(TInt aCommand)
	{
	switch(aCommand)
		{
		case EEikCmdExit:
		case EAknSoftkeyExit:
			Exit();
			break;

		case EClientCancel:
			// Cancel current transaction
			if(iClient->IsRunning())
				iClient->CancelTransaction();
			break;

		default:
			Panic(EClientUi);
			break;
		}
	}

// ----------------------------------------------------------------------------
// CClientAppUi::DynInitMenuPaneL()
//
// Initializes the menu pane when it's activated.
// ----------------------------------------------------------------------------
void CClientAppUi::DynInitMenuPaneL(TInt aMenuId, CEikMenuPane* aMenuPane)
	{
	// "Cancel" selection is only available when trasaction running in engine
	if (aMenuId == R_EXAMPLECLIENT_MENU)
		aMenuPane->SetItemDimmed(EClientCancel, !iClient->IsRunning());
	}
	
CSMS20* CClientAppUi::GetClient()
	{
	return iClient;
	}	
	
// end of file
