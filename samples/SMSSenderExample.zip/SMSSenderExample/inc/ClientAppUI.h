/*
 * ============================================================================
 *  Name     : CClientAppUi of ClientAppUI.h
 *  Part of  : SMS Sender Example for symbian sdk
 *  Created  : 22/05/2008
 *  Version  : 1.0
 *  Copyright:
 * ============================================================================
 */

#ifndef __CLIENT_APPUI_H__
#define __CLIENT_APPUI_H__

#include <aknappui.h>

/*
* Forward declarations
*/
class CClientAppView;
class CSMSSender;

class CClientAppUi : public CAknAppUi
	{
public:
	/*
	* ConstructL()
	*
	* Perform the second phase construction of a CClientAppUi object.
	*
	* Params:
	*		-
	*
	* Returns:
	* 		-
	*
	*/
	void ConstructL();

	/*
	* CClientAppUi()
	*
	* First phase construction of CClientAppUi.
	*
	* Params:
	*		-
	*
	* Returns:
	* 		-
	*
	*/
	CClientAppUi();

	/*
	* ~CClientAppUi()
	*
	* Destructor for CClientAppUi.
	*
	* Params:
	*		-
	*
	* Returns:
	* 		-
	*
	*/
	~CClientAppUi();

/*
* from CAknAppUi
*/
public:
	/*
	* HandleCommandL()
	*
	* Handles user commands.
	*
	* Params:
	*		aCommand: Command ID.
	*
	* Returns:
	* 		-
	*
	*/
	void HandleCommandL(TInt aCommand);

	/*
	* DynInitMenuPaneL()
	*
	* Provides dynamic initialization of the menu pane.
	* Called by framework when menu pane is activated.
	*
	* Params:
	*		aMenuId: Resource ID identifying the menu pane to initialise.
	*		aMenuPane: The in-memory representation of the menu pane.
	*
	* Returns:
	* 		-
	*
	*/
	void DynInitMenuPaneL(TInt aMenuId, CEikMenuPane* aMenuPane);

private:
	CClientAppView*	iAppView;
	CSMSSender*			iClient;
	};

#endif // __CLIENT_APPUI_H__
