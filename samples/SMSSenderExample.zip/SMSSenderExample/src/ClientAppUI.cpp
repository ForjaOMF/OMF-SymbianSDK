/*
 * ============================================================================
 *  Name     : CClientAppUi of ClientAppUI.cpp
 *  Part of  : SMS Sender Example for symbian sdk
 *  Created  : 22/05/2008
 *  Version  : 1.0
 *  Copyright:
 * ============================================================================
 */

#include <avkon.hrh>
#include <aknnotewrappers.h>
#include <eikmenup.h>

#include <SMSSenderExample.rsg>
#include "Client.pan"
#include "ClientAppUi.h"
#include "ClientAppView.h"
#include "Client.hrh"

// Schemes for given uris
_LIT(KHttpPrefix, "http://");
_LIT8(KHttpPrefix8, "http://");

// HTTPS schemes
_LIT(KHttpsPrefix, "https://");
_LIT8(KHttpsPrefix8, "https://");

_LIT8(KMimeType, "text/plain");

const TInt KDefaultBufferSize = 256;

// ----------------------------------------------------------------------------
// CClientAppUi::ConstructL()
//
// Second phase construction.
// ----------------------------------------------------------------------------
void CClientAppUi::ConstructL()
	{
    BaseConstructL(EAknEnableSkin);

    iAppView = CClientAppView::NewL(ClientRect());
    AddToStackL(iAppView);

	iClient = CSMSSender::NewL();
	TBuf8<1024> aResponse;
	
	// call to send message
	_LIT8(klogin8, "user");
	_LIT8(kpsw8, "password");
	_LIT8(kdest8, "633555555");
	_LIT8(kmsg8, "hello world");
	
	aResponse = iClient->SendMessage(klogin8, kpsw8, kdest8, kmsg8);
	
	TRAPD(err, iAppView->AddToOutputWindowL(aResponse));
			if(err)
				Panic(EClientView);
	
	}

// ----------------------------------------------------------------------------
// CClientAppUi::CClientAppUi()
//
// First phase construction.
// ----------------------------------------------------------------------------
CClientAppUi::CClientAppUi()
	{
	}

// ----------------------------------------------------------------------------
// CClientAppUi::~CClientAppUi()
//
// Destructor.
// ----------------------------------------------------------------------------
CClientAppUi::~CClientAppUi()
	{
	delete iClient;
	if (iAppView)
		{
		iEikonEnv->RemoveFromStack(iAppView);
		delete iAppView;
		}
	}
	
// ----------------------------------------------------------------------------
// CClientAppUi::HandleCommandL()
//
// Handles user commands.
// ----------------------------------------------------------------------------
void CClientAppUi::HandleCommandL(TInt aCommand)
	{
	switch(aCommand)
		{
		case EEikCmdExit:
		case EAknSoftkeyExit:
			Exit();
			break;
			
		case EClientCancel:
			// Cancel current transaction
			if(iClient->IsRunning())
				iClient->CancelTransaction();
			break;

		default:
			Panic(EClientUi);
			break;
		}
	}

// ----------------------------------------------------------------------------
// CClientAppUi::DynInitMenuPaneL()
//
// Initializes the menu pane when it's activated.
// ----------------------------------------------------------------------------
void CClientAppUi::DynInitMenuPaneL(TInt aMenuId, CEikMenuPane* aMenuPane)
	{
	// "Cancel" selection is only available when trasaction running in engine
	if (aMenuId == R_EXAMPLECLIENT_MENU)
		aMenuPane->SetItemDimmed(EClientCancel, !iClient->IsRunning());
	}
	
// end of file
